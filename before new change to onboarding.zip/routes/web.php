<?php


// API-only application - no web routes needed
// All routes are in routes/api.php
